async function welcomeMessageOpenConfigHUD() {
  var hud = document.getElementById("welcomeMessageConfigHUD");
  hud.style.display = "block";
}

async function welcomeMessageCloseConfigHUD() {
  var hud = document.getElementById("welcomeMessageConfigHUD");
  hud.style.display = "none";
}
